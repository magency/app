"""Initialize the index package"""

from base import *
from typ import *